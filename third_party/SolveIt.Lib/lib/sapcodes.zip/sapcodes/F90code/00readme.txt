FUNCTION:  This is the ASCII overview file for the Fortran 90 codes
           accompanying the text  Fundamentals of Numerical Computing.
AUTHORS:   Lawrence Shampine, Richard Allen, Steven Pruess
DATE:      January, 1998

The file saplib.f90 contains two modules.  The module SAP_CODES contains
all the subprograms provided for the text. The KIND of the working precision
is defined in the module SAP_WP as WP = SELECTED_REAL_KIND(10,50).  This
module is USEd in all the example programs and all real constants are defined
in terms of the working precision, WP.  Example programs for each of the
subprograms are provided in the files

  xlinsys.f90 -   an example of the solution of a system of linear equations
                  using FACTOR/SOLVE.

  xspline.f90 -   an example of interpolation with a complete cubic spline
                  using SPCOEF/SVALUE.

  xzero.f90   -   an example of finding a zero of a function using ZERO.

  xadapt.f90  -   an example of computing a definite integral using ADAPT.

  x1rke.f90   -   an example of the solution of a system of ordinary
                  differential equations using RKE.

  x2rke.f90   -   an example of the solution of a system of ordinary
                  differential equations using RKE and YVALUE.


The programs have been coded in Essential LF90, a proper subset of Fortran 90
proposed by Lahey Computer Systems.  A rationale for the subset can be found at
http://www.lahey.com.  All the programs have been compiled and run with at least
three compilers.  Comments should be directed to shampine@na-net.ornl.gov.

