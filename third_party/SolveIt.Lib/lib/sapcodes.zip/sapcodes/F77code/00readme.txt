FUNCTION:     This is the ASCII overview file for the FORTRAN 77 codes 
              accompanying the text  Fundamentals of Numerical Computing.
AUTHORS:      Lawrence Shampine, Richard Allen, Steven Pruess
DATE:         June 25, 1994
LAST CHANGE:  August 25, 1995

The following FORTRAN 77 files are in this directory:

      linsys.f   -   the source code for subroutines FACTOR and SOLVE
      xlinsys.f  -   a sample driver for subroutines FACTOR and SOLVE

      spline.f   -   the code for subroutines SPCOEF and SVALUE
      xspline.f  -   a sample driver for the spline subroutines

      zero.f     -   the code for subroutine ZERO
      xzero.f    -   a sample driver for the zero finder

      adapt.f    -   the code for subroutine ADAPT 
      xadapt.f   -   a sample driver for the adaptive quadrature subroutine

      rke.f      -   the code for the subroutines RKE and YVALUE
      x1rke.f    -   a simple sample driver for RKE
      x2rke.f    -   another sample driver for RKE and YVALUE

The preferred way of using these files is to first compile the source code
for the subprograms, e.g., using the f77 compiler under UNIX or LINUX

      f77 -c -lm linsys.f spline.f zero.f adapt.f rke.f

Henceforth, only the respective object files should be used, e.g.,

      f77 -lm xlinsys.f linsys.o

The use of make files is also encouraged, e.g., in Makefile or makefile

	a.out:	xlinsys.o linsys.o fnc_util.o
		f77 xlinsys.o linsys.o fnc_util.o -lm

	xlinsys.o:	xlinsys.f
			f77 -c xlinsys.f

	linsys.o	linsys.f
			f77 -c xlinsys.f

	fnc_util.o	fnc_util.f
			f77 -c fnc_util.f
