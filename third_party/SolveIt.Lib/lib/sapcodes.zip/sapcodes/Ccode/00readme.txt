FUNCTION:     This is the ASCII overview file for the C codes accompanying 
              the text  Fundamentals of Numerical Computing.
AUTHORS:      Lawrence Shampine, Richard Allen, Steven Pruess
DATE:         August 25, 1995                                     
LAST CHANGE:  July 30, 1998

The following C files are in this directory:

      linsys.c   -  the C source code for functions Factor and Solve
      xlinsys.c  -  a sample C driver for functions Factor and Solve

      spline.c   -  the C code for functions Spline_coeff and Spline_value
      xspline.c  -  a sample C driver for the spline functions

      zero.c     -  the C code for function Zero
      xzero.c    -  a sample C driver for the zero finder

      adapt.c    -  the C code for function Adapt
      xadapt.c   -  a sample C driver for the adaptive quadrature function

      rke.c      -  the C code for function Rke
      x1rke.c    -  a simple sample C driver for Rke
      x2rke.c    -  another sample C driver for Rke

      fnc.h      -  the header file for all the codes
      fnc_util.c -  the C code for various auxiliary functions   

============================================================================
In a UNIX environment

The preferred way of using these files is to first compile the source code
for the functions either singly or all at once.  E.g., using the cc compiler
under UNIX or LINUX

      cc -c linsys.c spline.c zero.c adapt.c rke.c fnc_util.c -lm

Once this is done, only the respective object files should be used, e.g.,

      cc xlinsys.c linsys.o fnc_util.o -lm

The use of make files is also encouraged, e.g., in Makefile or makefile

	a.out:	xlinsys.o linsys.o fnc_util.o
		cc xlinsys.o linsys.o fnc_util.o -lm

	xlinsys.o:	xlinsys.c
			cc -c xlinsys.c

	linsys.o	linsys.c
			cc -c linsys.c

	fnc_util.o	fnc_util.c
			cc -c fnc_util.c
============================================================================
In a Visual C/C++ environment

You may want to create your program with a standard text editor (notepad
will work), though an editor comes with Developer's Studio.

1.  Open up Visual C/C++  (by using the mouse to maneuver through 
    Start--Applications--Microsoft Developer's Studio) or clicking 
    on the Visual C/C++ icon if it's on the desktop.

2.  I'll assume you are starting from a previous file (on your floppy
    or on your storage area on the hard drive) that might be a template 
    from the text or elsewhere. Click on File from the Menu Bar (second 
    line down), then Open (as in file) rather than Open Workspace.  You
    may have to use the various arrow icons to find the right directory 
    where your stuff resides.   You'll be prompted about a file name 
    and a workspace; be agreeable to any queries you don't understand.  
    Your program should appear in the bottom window (you'll probably want 
    to resize or close most of the other parts on the screen), and you 
    can now edit it (all keys work as you would expect, the current line 
    & column number is displayed near the lower right).  When you are 
    finished with any edits, select Build from the Menu Bar (second from 
    the top of the screen), which is the workhorse button in development.  
    Under this Menu, at this point and click on compile.  After a while 
    you will hear a beep meaning compilation is done (correctly or not).  
    Depending on how you have Developer's Studio configured, the error 
    info should appear in its own viewing window at the bottom of the 
    screen.  If not, click on File/Open again and then select the file 
    with extension .plg, which contains the error information.  To see 
    this file in the big window, you may have to click on "All files (*.*)" 
    in the Files-of-type box in the bottom half.   Window display can 
    be alternated between .c and .plg by clicking on Window on the Menu 
    Bar, and selecting the file you want displayed from the list at the 
    bottom.  If there are errors correct them, if not you are ready 
    to continue.  

    To incorporate the provided C files you will have to click on
    Add-To-Project and then Files, under Projects on the Menu Bar.

4.  Click on Build and then "build ...exe".  Again some time will pass 
    until a beep is heard (you can check to see if the ! icon is lit too).
    Again, you probably should check the .plg file to make sure there were
    no errors at the linking stage.  If Ok, then one final click on Build
    followed by run executable (the one with the !) will run the job.

5.  For large projects, Visual's files can get pretty big, so it's a good
    idea to "clean house" from time to time before you log off.

6.  There are many files produced by Visual, for example, (for $ substitute
    the name of your file)
       $.plg             error log
       $.dsp             project file
       $.dsw             project workspace
       $.opt             ???
       $.ncb             ???
       debug\$.exe       executable (click to run)
       debug\$.obj       object
       debug\$.ilk       ???
       debug\$.pch       ???
       debug\$.pdb       ???
    Most of these are not text (so are not viewable).
============================================================================
In a Borland environment

Note:  unless otherwise noted, click refers to the LEFT mouse button.

(1)  Create the main program as usual, e.g., by editing one of the sample 
     drivers.  For this illustration, assume it is called main.c; more
     descriptive names are preferred.

(2)  Click on Project.

(3)  Click on New (or Open if the project has already been created).

(4)  A window will open up asking for a project name and a target (and much 
     more that you can ignore).   Change the project name to what you want 
     by clicking on this area and overwriting with your name, here, main 
     (but no extension).  Make sure you are in the correct subdirectory - to 
     insure this, you can use Browse to get in the right subdirectory and 
     name the project.  Naming the project should automatically change the 
     target name.  In our illustration, we would use main.ide as the name.

     IMPORTANT: select EasyWin [.exe] as the TargetType on the left.

     Click on OK.  The target window should close and you should see a new 
     smaller window for your project with a list (tree) of files:

     .   - main [.exe]       		(actually the minus is in a box)
            |
     .      ---main [.cpp]
            |        
     .      ---main [.def]
            |
     .      ---main [.rc]

     If you have a + instead of a - in the box next to the main.exe, click 
     the + to open up this tree.

     Unless you know how to use .rc and .def files, you should delete them.  
     To do this, on each file click (if necessary) to select, and then click 
     the RIGHT button, which should open up a window with many options: click 
     Delete (or you can just select and then press the Delete key).  

     Finally, add a link to your implementation file by selecting the main.exe
     file (click on it), then click the RIGHT button to open the window with 
     many options.  Click on Add and type in the name of your implementation 
     file, here, impl.cpp

(5)  Now compile each of your source (.c) files.  Select one from the 
     project window (with the tree in it - if this is not visible you can find 
     it by clicking on Window and selecting, or by View and then Project), 
     click on Project, then Compile.  If there are syntax errors, correct 
     them and repeat.  Proceed similarly for the other source file.

(6)  To execute, again select the project window, then click Debug and Run, 
     as usual.

(7)  Steps (5) and (6) can be combined by pulling down the Project menu, then 
     click on either

	Make All	(compiles recently altered .c files, then executes)
     or
  	Build All	(compiles all .c files, then executes)


