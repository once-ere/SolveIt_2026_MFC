/* FUNCTION:     This is the file containing C auxiliary math functions.
   AUTHORS:      Lawrence Shampine, Richard Allen, Steven Pruess for
                 the text  Fundamentals of Numerical Computing
   DATE:         December 8, 1995 
   LAST CHANGE:  July 3, 1996                                      */

/*/////////////////////////////////////////////////////////////////////////////
//    This file contains utilities for common mathematical operations.
/////////////////////////////////////////////////////////////////////////////*/

double abs_d(x)
   double x;

/* Return the absolute value of the double value x.     */

{
   if (x >= 0)
      return (x);
   else
      return (-x);
}

double max_d(x, y)
   double x, y;

/* Return the maximum of double values x and y.      */

{
   if (x >= y)
      return (x);
   else
      return (y);
}

double min_d(x, y)
   double x, y;

/* Return the minimum of double values x and y.     */

{
   if (x <= y)
      return (x);
   else
      return (y);
}

double sign( x, y)
   double x, y;

/* Attach the algebraic sign of y to the absolute value of x.    */

{
   if (y >= 0.0)
      return (abs_d(x));
   else
      return (-abs_d(x));
}
