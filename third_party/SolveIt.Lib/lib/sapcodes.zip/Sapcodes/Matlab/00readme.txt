FUNCTION:  This is the ASCII overview file for the MATLAB codes
           accompanying the text  Fundamentals of Numerical Computing.
AUTHORS:   Lawrence Shampine, Richard Allen, Steven Pruess
DATE:      January, 1998

These programs are implementations in MATLAB of the algorithms of the
text.  Because they are illustrative, they do not exploit fully the 
capabilities of the language.  MATLAB is a computing environment that
includes production-grade codes which in some cases are to be preferred.
For instance, the \ operation is a polyalgorithm for the solution of linear
systems that solves problems Factor and Solve do not address, viz. under-
and over-determined systems.  It recognizes automatically permutations of
triangular matrices and symmetric positive definite matrices and deals with
them appropriately.  The computations are optimized for both language and
hardware.  Also, MATLAB 5 includes a new suite of ODE codes that are more
powerful than Rke and Yvalue.

The MATLAB versions of the programs have to be organized a little
differently from other languages because prior to MATLAB 5, auxiliary
functions had to be in separate files.  All example programs state clearly
which auxiliary functions are required to be in the path.

Chapter 2 Systems of Linear Equations

  Tools...
  
  Factor.m: Factor decomposes the matrix A using Gaussian elimination
            and estimates its condition number.  Factor is used in
            conjunction with Solve to solve A*x = b.

  Solve.m:  Solve solves the linear system A*x = b using the decomposition
            obtained from Factor.
  Examples...
  
  Xlinsys.m:  An example of the solution of a system of linear equations.
              REQUIRES Factor.m and Solve.m.

Chapter 3 Interpolation

  Tools...
  
  Spcoef.m:  Spcoef calculates coefficients defining a smooth cubic
             interpolatory spline S. 

  Svalue.m:  Evaluates the spline S at t using coefficients from Spcoef.

  Examples...

  Xspline.m:  An example of interpolation with a complete cubic spline.
              REQUIRES Spcoef.m and Svalue.m.

Chapter 4 Roots of Nonlinear Equations

  Tools...

  Zero.m: Zero computes a zero of the nonlinear equation f(x) = 0 
          when f(x) is a continuous real function of a single real 
          variable x.  

  Examples...

  Xzero.m:  An example of finding a zero of a function.
            REQUIRES Zero.m and Xzerof.m.

  Xzerof.m:  Function for Xzero.m.
 
Chapter 5 Numerical Integration

  Tools...

  Adapt.m: Adapt estimates the definite integral of f(x) from a to b
           using an adaptive quadrature scheme based on Gauss-Kronrod
           (3,7) formulas.  REQUIRES Add.m and Quad.m.

  Add.m: Auxiliary program required by Adapt.  Adds an entry to the
         end of the queue.

  Quad.m: Auxiliary program required by Adapt.  Does Gauss-Kronrod (3,7)
          quadrature over (alpha,beta). 

  Examples...

  Xadapt.m:  An example of computing a definite integral.
             REQUIRES Adapt.m, Add.m, Quad.m, and Xadaptf.m.

  Xadaptf.m:  Function for Xadapt.m.

Chapter 6 Initial Value Problems for Ordinary Differential Equations

  Tools...

  Rke.m:  Rke integrates a system of neq first order ordinary differ-
          ential equations over one step using a Runge-Kutta method due 
          to R. England.  It provides for the evaluation of the solution 
          within the step by interpolation.  

  Yvalue.m:  Evaluates quintic Hermite interpolants based on output from Rke.

  Examples...

  X1rke.m:  An example of the solution of a system of ordinary differential
            equations using Rke.
            REQUIRES Rke.m and X1rkef.m.

  X1rkef.m:  Function for example of X1rke.m.

  X2rke.m:  An example of the solution of a system of ordinary differential
            equations using Rke and Yvalue.
            REQUIRES Rke.m, Yvalue.m, and X2rkef.m.

  X2rkef.m:  Function for example of X2rke.m and of Xmrke.m.

  Xmrke.m:  An example of the use of Rke that is more typical of computing
            in MATLAB.  Same problem as in X2rke.m, but the solution is 
            plotted both as a function of the independent variable and 
            in the phase plane.  
            REQUIRES Rke.m, Yvalue.m, and X2rkef.m.


All these programs have been executed successfully using both MATLAB 4.2
and 5.1. Comments should be directed to shampine@na-net.ornl.gov.

