function yprime = X2rkef(x, y)
%  Function used by the example programs X2rke.m and Xmrke.m

yprime = zeros(2,1);
yprime(1) =  y(2);
yprime(2) = -y(1) - (y(1)^2 - 1) * y(2);
