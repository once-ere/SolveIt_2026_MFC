function yprime = X1rkef(x, y)
%  Function used by the example program X1rke.m.

yprime = zeros(2,1); 
yprime(1) =  y(1);
yprime(2) = -y(2);
