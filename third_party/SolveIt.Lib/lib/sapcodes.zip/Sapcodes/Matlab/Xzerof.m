function y = Xzerof(x)
%  Function used by the example program Xzero.m.

global nfeval

y = exp(-x) - 2 * x;
nfeval = nfeval + 1;
