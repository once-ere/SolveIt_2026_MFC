function y = Xadaptf(x)
%  Function used by the example program Xadapt.m.

global nfeval

y = exp(x);
nfeval = nfeval + 1;
